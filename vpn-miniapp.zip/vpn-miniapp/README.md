# VPN Mini App для Telegram

## Структура

```
vpn-miniapp/
├── index.html       # Mini App: экран выбора тарифа
├── style.css         # Стили (адаптируются под тему Telegram)
├── app.js             # Логика: выбор тарифа, оплата, получение конфига
└── backend/
    ├── bot.py             # Бот + HTTP API (aiogram + aiohttp)
    └── requirements.txt
```

## 1. Frontend (Mini App)

1. Залейте `index.html`, `style.css`, `app.js` в публичный репозиторий на GitHub.
2. Включите GitHub Pages (Settings → Pages → Deploy from branch → main / root).
3. Получите URL вида `https://username.github.io/vpn-miniapp/`.
4. В `app.js` замените `API_BASE` на адрес вашего backend-сервера.

## 2. Backend

1. Установите зависимости:
   ```bash
   pip install -r backend/requirements.txt
   ```
2. В `backend/bot.py` заполните:
   - `BOT_TOKEN` — токен от @BotFather
   - `PROVIDER_TOKEN` — токен платёжного провайдера
     (@BotFather → выбрать бота → Payments → подключить ЮKassa / другого провайдера)
   - `WEBAPP_URL` — ссылка на ваш GitHub Pages из шага выше
   - `your-backend-domain.com` в коде и в `app.js` — реальный домен, где будет
     развёрнут `bot.py` (нужен HTTPS! Можно использовать VPS + Nginx + Certbot,
     либо Render/Railway для быстрого старта)
3. Реализуйте настоящую генерацию конфигов в `generate_wireguard_config()` —
   сейчас там заглушка со случайными данными для демонстрации потока.
4. Запустите:
   ```bash
   python backend/bot.py
   ```

## 3. Регистрация Mini App в BotFather

1. `@BotFather` → `/mybots` → ваш бот → **Bot Settings → Menu Button → Configure Menu Button**
2. Вставьте ссылку на GitHub Pages.

## Как это работает целиком

1. Пользователь открывает мини-приложение → выбирает тариф → жмёт кнопку оплаты.
2. Frontend просит backend создать `invoiceLink` через Bot API (`create_invoice_link`).
3. Открывается нативное окно оплаты Telegram (`tg.openInvoice`).
4. После оплаты Telegram сам присылает боту `successful_payment`.
5. Backend генерирует VPN-конфиг и:
   - отправляет файл прямо в чат с ботом,
   - сохраняет ссылку на файл, чтобы Mini App тоже мог её показать (`/api/order-status`).

## Важно про безопасность

- `initData` **обязательно** проверяется на backend (см. `validate_init_data`) —
  иначе кто угодно сможет создавать заказы от чужого имени.
- Не храните заказы в памяти (`ORDERS = {}`) в продакшене — используйте БД,
  иначе всё слетит при перезапуске сервера.
- `PROVIDER_TOKEN` и `BOT_TOKEN` никогда не должны попадать в публичный
  репозиторий — храните их в переменных окружения, а не в коде.
