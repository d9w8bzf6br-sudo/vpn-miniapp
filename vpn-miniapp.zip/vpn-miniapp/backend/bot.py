"""
Пример backend для Telegram-бота по продаже VPN.

Стек: aiogram 3.x + aiohttp
Что делает:
  1. /start — отправляет кнопку с Mini App
  2. POST /api/create-invoice — создаёт ссылку на оплату (Telegram Payments / ЮKassa)
  3. pre_checkout_query — подтверждает возможность оплаты
  4. successful_payment — после оплаты генерирует WireGuard-конфиг и сохраняет его
  5. GET /api/order-status — Mini App опрашивает, готов ли конфиг
  6. GET /files/<name> — отдаёт готовый .conf файл

ВАЖНО перед запуском:
  - Впишите BOT_TOKEN и PROVIDER_TOKEN (получаете у @BotFather -> Payments -> ЮKassa)
  - Замените generate_wireguard_config() на реальную интеграцию с вашим WG-сервером
    (например, через SSH/API к серверу, где выполняется `wg genkey` и добавляется peer)
  - Для продакшена замените ORDERS (dict в памяти) на базу данных (Postgres/SQLite)
  - Обязательно проверяйте initData (см. validate_init_data) — без этого любой человек
    сможет дёргать API от чужого имени
"""

import asyncio
import hashlib
import hmac
import json
import logging
import secrets
import uuid
from urllib.parse import parse_qsl

from aiohttp import web
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart
from aiogram.types import (
    Message,
    LabeledPrice,
    PreCheckoutQuery,
    WebAppInfo,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("vpn-bot")

# ---------- НАСТРОЙКИ ----------
BOT_TOKEN = "PASTE_YOUR_BOT_TOKEN_HERE"
PROVIDER_TOKEN = "PASTE_YOUR_PAYMENT_PROVIDER_TOKEN_HERE"  # из BotFather -> Payments
WEBAPP_URL = "https://your-username.github.io/vpn-miniapp/"  # ваш GitHub Pages URL
CURRENCY = "RUB"

PLANS = {
    "1m": {"title": "VPN 1 месяц", "price": 199},
    "3m": {"title": "VPN 3 месяца", "price": 499},
    "12m": {"title": "VPN 12 месяцев", "price": 1499},
}

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

# orderId -> { user_id, plan_id, status, config_url }
ORDERS: dict[str, dict] = {}


# ---------- ПРОВЕРКА initData (обязательно!) ----------
def validate_init_data(init_data: str, bot_token: str) -> dict | None:
    """
    Проверяет подпись initData, которую Mini App присылает на backend.
    Возвращает распарсенные данные пользователя, либо None если подпись неверна.
    """
    try:
        parsed = dict(parse_qsl(init_data, strict_parsing=True))
        received_hash = parsed.pop("hash", None)
        if not received_hash:
            return None

        data_check_string = "\n".join(
            f"{k}={v}" for k, v in sorted(parsed.items())
        )
        secret_key = hmac.new(
            b"WebAppData", bot_token.encode(), hashlib.sha256
        ).digest()
        computed_hash = hmac.new(
            secret_key, data_check_string.encode(), hashlib.sha256
        ).hexdigest()

        if not hmac.compare_digest(computed_hash, received_hash):
            return None

        user_raw = parsed.get("user")
        return json.loads(user_raw) if user_raw else {}
    except Exception as e:
        log.warning("initData validation failed: %s", e)
        return None


# ---------- ГЕНЕРАЦИЯ VPN-КОНФИГА (заглушка — замените на реальную) ----------
def generate_wireguard_config(user_id: int) -> tuple[str, str]:
    """
    ЗАГЛУШКА. В реальном проекте здесь нужно:
      - сгенерировать пару ключей (или дёрнуть API вашего WG-сервера)
      - добавить peer на сервере
      - вернуть содержимое .conf файла

    Возвращает (filename, file_content).
    """
    fake_private_key = secrets.token_urlsafe(32)
    fake_server_public_key = "SERVER_PUBLIC_KEY_HERE"

    config = f"""[Interface]
PrivateKey = {fake_private_key}
Address = 10.8.0.{secrets.randbelow(200) + 2}/32
DNS = 1.1.1.1

[Peer]
PublicKey = {fake_server_public_key}
Endpoint = your-vpn-server.com:51820
AllowedIPs = 0.0.0.0/0
PersistentKeepalive = 25
"""
    filename = f"vpn_{user_id}_{uuid.uuid4().hex[:8]}.conf"
    return filename, config


# ---------- ХЕНДЛЕРЫ БОТА ----------
@dp.message(CommandStart())
async def cmd_start(message: Message):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🔐 Открыть магазин", web_app=WebAppInfo(url=WEBAPP_URL))]
        ]
    )
    await message.answer(
        "Добро пожаловать! Выберите тариф VPN в мини-приложении:",
        reply_markup=kb,
    )


@dp.pre_checkout_query()
async def process_pre_checkout(pre_checkout_query: PreCheckoutQuery):
    # Здесь можно ещё раз проверить, что заказ существует и не оплачен
    await pre_checkout_query.answer(ok=True)


@dp.message(F.successful_payment)
async def process_successful_payment(message: Message):
    payload = message.successful_payment.invoice_payload  # тут лежит наш orderId
    order = ORDERS.get(payload)
    if not order:
        log.error("Order %s not found after payment!", payload)
        return

    order["status"] = "paid"

    filename, config_content = generate_wireguard_config(message.from_user.id)

    # Сохраняем файл, чтобы отдать его через /files/<name>
    with open(f"generated_configs/{filename}", "w") as f:
        f.write(config_content)

    order["config_url"] = f"https://your-backend-domain.com/files/{filename}"
    order["status"] = "ready"

    # Дублируем конфиг прямо в чат — на случай, если пользователь закрыл Mini App
    await bot.send_document(
        chat_id=message.chat.id,
        document=(filename, config_content.encode()),
        caption="Ваш VPN-конфиг готов ✅\nИмпортируйте файл в приложение WireGuard.",
    )


# ---------- HTTP API ДЛЯ MINI APP ----------
async def api_create_invoice(request: web.Request):
    body = await request.json()
    init_data = body.get("initData", "")
    plan_id = body.get("planId")

    user = validate_init_data(init_data, BOT_TOKEN)
    if user is None:
        return web.json_response({"error": "invalid_init_data"}, status=403)

    plan = PLANS.get(plan_id)
    if not plan:
        return web.json_response({"error": "unknown_plan"}, status=400)

    order_id = uuid.uuid4().hex
    ORDERS[order_id] = {
        "user_id": user.get("id"),
        "plan_id": plan_id,
        "status": "pending",
        "config_url": None,
    }

    invoice_link = await bot.create_invoice_link(
        title=plan["title"],
        description=f"Подписка VPN: {plan['title']}",
        payload=order_id,
        provider_token=PROVIDER_TOKEN,
        currency=CURRENCY,
        prices=[LabeledPrice(label=plan["title"], amount=plan["price"] * 100)],  # в копейках
    )

    return web.json_response({"invoiceLink": invoice_link, "orderId": order_id})


async def api_order_status(request: web.Request):
    order_id = request.query.get("orderId")
    order = ORDERS.get(order_id)
    if not order:
        return web.json_response({"error": "not_found"}, status=404)

    ready = order["status"] == "ready"
    return web.json_response({"ready": ready, "configUrl": order.get("config_url")})


def create_app() -> web.Application:
    import os
    os.makedirs("generated_configs", exist_ok=True)

    app = web.Application()

    # CORS для запросов из Mini App
    async def cors_middleware(app, handler):
        async def middleware_handler(request):
            if request.method == "OPTIONS":
                return web.Response(headers={
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                    "Access-Control-Allow-Headers": "Content-Type",
                })
            response = await handler(request)
            response.headers["Access-Control-Allow-Origin"] = "*"
            return response
        return middleware_handler

    app.middlewares.append(cors_middleware)

    app.router.add_post("/api/create-invoice", api_create_invoice)
    app.router.add_get("/api/order-status", api_order_status)
    app.router.add_static("/files/", path="generated_configs", show_index=False)

    return app


async def main():
    app = create_app()
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", 8080)
    await site.start()
    log.info("HTTP API запущен на :8080")

    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
